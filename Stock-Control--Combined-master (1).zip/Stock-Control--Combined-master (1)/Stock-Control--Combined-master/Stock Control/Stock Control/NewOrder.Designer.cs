﻿namespace Stock_Control
{
    partial class NewOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_addOrder = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.txt_orderStatus = new System.Windows.Forms.TextBox();
            this.txt_tax = new System.Windows.Forms.TextBox();
            this.txt_createdDate = new System.Windows.Forms.TextBox();
            this.txt_deliveryDate = new System.Windows.Forms.TextBox();
            this.txt_total = new System.Windows.Forms.TextBox();
            this.txt_vendorID = new System.Windows.Forms.TextBox();
            this.txt_deliveryAddress = new System.Windows.Forms.TextBox();
            this.txt_terms = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_userID = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_orderNotes = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_orderID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_addOrder
            // 
            this.btn_addOrder.Location = new System.Drawing.Point(62, 406);
            this.btn_addOrder.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_addOrder.Name = "btn_addOrder";
            this.btn_addOrder.Size = new System.Drawing.Size(144, 23);
            this.btn_addOrder.TabIndex = 112;
            this.btn_addOrder.Text = "Add New Order";
            this.btn_addOrder.UseVisualStyleBackColor = true;
            this.btn_addOrder.Click += new System.EventHandler(this.btn_addOrder_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Created",
            "Pending Approval",
            "Awaiting Items",
            "Completed"});
            this.comboBox1.Location = new System.Drawing.Point(998, 123);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(183, 24);
            this.comboBox1.TabIndex = 148;
            // 
            // txt_orderStatus
            // 
            this.txt_orderStatus.Location = new System.Drawing.Point(890, 124);
            this.txt_orderStatus.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_orderStatus.Name = "txt_orderStatus";
            this.txt_orderStatus.Size = new System.Drawing.Size(100, 22);
            this.txt_orderStatus.TabIndex = 142;
            // 
            // txt_tax
            // 
            this.txt_tax.Location = new System.Drawing.Point(153, 208);
            this.txt_tax.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_tax.Name = "txt_tax";
            this.txt_tax.Size = new System.Drawing.Size(100, 22);
            this.txt_tax.TabIndex = 141;
            // 
            // txt_createdDate
            // 
            this.txt_createdDate.Location = new System.Drawing.Point(164, 298);
            this.txt_createdDate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_createdDate.Name = "txt_createdDate";
            this.txt_createdDate.Size = new System.Drawing.Size(185, 22);
            this.txt_createdDate.TabIndex = 140;
            // 
            // txt_deliveryDate
            // 
            this.txt_deliveryDate.Location = new System.Drawing.Point(164, 256);
            this.txt_deliveryDate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_deliveryDate.Name = "txt_deliveryDate";
            this.txt_deliveryDate.Size = new System.Drawing.Size(185, 22);
            this.txt_deliveryDate.TabIndex = 139;
            // 
            // txt_total
            // 
            this.txt_total.Location = new System.Drawing.Point(562, 256);
            this.txt_total.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_total.Name = "txt_total";
            this.txt_total.Size = new System.Drawing.Size(100, 22);
            this.txt_total.TabIndex = 138;
            // 
            // txt_vendorID
            // 
            this.txt_vendorID.Location = new System.Drawing.Point(562, 211);
            this.txt_vendorID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_vendorID.Name = "txt_vendorID";
            this.txt_vendorID.Size = new System.Drawing.Size(100, 22);
            this.txt_vendorID.TabIndex = 137;
            // 
            // txt_deliveryAddress
            // 
            this.txt_deliveryAddress.Location = new System.Drawing.Point(562, 166);
            this.txt_deliveryAddress.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_deliveryAddress.Name = "txt_deliveryAddress";
            this.txt_deliveryAddress.Size = new System.Drawing.Size(100, 22);
            this.txt_deliveryAddress.TabIndex = 136;
            // 
            // txt_terms
            // 
            this.txt_terms.Location = new System.Drawing.Point(562, 118);
            this.txt_terms.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_terms.Name = "txt_terms";
            this.txt_terms.Size = new System.Drawing.Size(100, 22);
            this.txt_terms.TabIndex = 135;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(792, 127);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(93, 17);
            this.label11.TabIndex = 134;
            this.label11.Text = "Order Status:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(433, 261);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(44, 17);
            this.label10.TabIndex = 133;
            this.label10.Text = "Total:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(433, 216);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(75, 17);
            this.label9.TabIndex = 132;
            this.label9.Text = "Vendor ID:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(433, 167);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(119, 17);
            this.label8.TabIndex = 131;
            this.label8.Text = "Delivery Address:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(433, 123);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 17);
            this.label7.TabIndex = 130;
            this.label7.Text = "Terms:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(61, 301);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(96, 17);
            this.label6.TabIndex = 129;
            this.label6.Text = "Created Date:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(61, 260);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 17);
            this.label5.TabIndex = 128;
            this.label5.Text = "Delivery Date:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(59, 211);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 17);
            this.label4.TabIndex = 127;
            this.label4.Text = "Tax:";
            // 
            // txt_userID
            // 
            this.txt_userID.Location = new System.Drawing.Point(154, 165);
            this.txt_userID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_userID.Name = "txt_userID";
            this.txt_userID.Size = new System.Drawing.Size(100, 22);
            this.txt_userID.TabIndex = 126;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(59, 169);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 17);
            this.label3.TabIndex = 125;
            this.label3.Text = "User ID:";
            // 
            // txt_orderNotes
            // 
            this.txt_orderNotes.Location = new System.Drawing.Point(882, 164);
            this.txt_orderNotes.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_orderNotes.Multiline = true;
            this.txt_orderNotes.Name = "txt_orderNotes";
            this.txt_orderNotes.Size = new System.Drawing.Size(129, 22);
            this.txt_orderNotes.TabIndex = 124;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(789, 169);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 17);
            this.label2.TabIndex = 123;
            this.label2.Text = "Order notes:";
            // 
            // txt_orderID
            // 
            this.txt_orderID.Location = new System.Drawing.Point(154, 118);
            this.txt_orderID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_orderID.Name = "txt_orderID";
            this.txt_orderID.Size = new System.Drawing.Size(100, 22);
            this.txt_orderID.TabIndex = 122;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(59, 123);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 17);
            this.label1.TabIndex = 121;
            this.label1.Text = "Order ID:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(531, 27);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(186, 31);
            this.label12.TabIndex = 120;
            this.label12.Text = "Add new order";
            // 
            // NewOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1283, 609);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.txt_orderStatus);
            this.Controls.Add(this.txt_tax);
            this.Controls.Add(this.txt_createdDate);
            this.Controls.Add(this.txt_deliveryDate);
            this.Controls.Add(this.txt_total);
            this.Controls.Add(this.txt_vendorID);
            this.Controls.Add(this.txt_deliveryAddress);
            this.Controls.Add(this.txt_terms);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txt_userID);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_orderNotes);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_orderID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.btn_addOrder);
            this.Name = "NewOrder";
            this.Text = "NewOrder";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_addOrder;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox txt_orderStatus;
        private System.Windows.Forms.TextBox txt_tax;
        private System.Windows.Forms.TextBox txt_createdDate;
        private System.Windows.Forms.TextBox txt_deliveryDate;
        private System.Windows.Forms.TextBox txt_total;
        private System.Windows.Forms.TextBox txt_vendorID;
        private System.Windows.Forms.TextBox txt_deliveryAddress;
        private System.Windows.Forms.TextBox txt_terms;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_userID;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_orderNotes;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_orderID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label12;
    }
}