﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stock_Control
{
    public partial class NewOrder : Form
    {
        public NewOrder()
        {
            InitializeComponent();
        }

        SqlDataReader myReader = null;
        SqlCommand cmd;
        SqlCommand s;
        SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-MTC8R1N\MICHAEL;Initial Catalog=AccountsPayable;Integrated Security=True");
        SqlDataAdapter adapt;
        int userid = 1234;
        int vendorid = 2345;

        private void btn_addOrder_Click(object sender, EventArgs e)
        {
            conn.Open();
            cmd = new SqlCommand("if NOT exists(select * from TBL_PURCHASE_ORDER where NUM_POID = @NUM_POID) INSERT INTO TBL_PURCHASE_ORDER (NUM_POID, CHR_notes, NUM_userID, NUM_tax, DT_delivery_date, DT_created_date, CHR_terms, CHR_deliveryAddress, NUM_vendorID, FT_total, NUM_POstatus)" +
                "VALUES (@NUM_POID, @CHR_notes, @NUM_userID, @NUM_tax, @DT_delivery_date, @DT_created_date, @CHR_terms, @CHR_deliveryAddress, @NUM_vendorID, @FT_total, @NUM_POstatus)", conn);


            if (txt_orderID.Text == "" || txt_deliveryDate.Text == "" )

            {
                MessageBox.Show("Please fill necessary fields");
            }

            else
            {
                
                cmd.Parameters.AddWithValue("@NUM_POID", txt_orderID.Text);
             
                
                
                cmd.Parameters.AddWithValue("@CHR_notes", txt_orderNotes.Text);
                cmd.Parameters.AddWithValue("@NUM_userID", userid);
                cmd.Parameters.AddWithValue("@NUM_tax", txt_tax.Text);
                cmd.Parameters.AddWithValue("@DT_delivery_date", txt_deliveryDate.Text);
                cmd.Parameters.AddWithValue("@DT_created_date", txt_createdDate.Text = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:sszzz"));
                cmd.Parameters.AddWithValue("@CHR_terms", txt_terms.Text);
                cmd.Parameters.AddWithValue("@CHR_deliveryAddress", txt_deliveryAddress.Text);
                cmd.Parameters.AddWithValue("@NUM_vendorID", vendorid);
                cmd.Parameters.AddWithValue("@FT_total", txt_total.Text);
                cmd.Parameters.AddWithValue("@NUM_POstatus", txt_orderStatus.Text);



                cmd.ExecuteNonQuery();
                MessageBox.Show("Success");
                ClearData();
            }
            conn.Close();

        }

        private void ClearData()
        {
            txt_orderID.Text = "";
            txt_orderNotes.Text = "";
            txt_userID.Text = "";
            txt_tax.Text = "";
            txt_deliveryDate.Text = "";
            txt_createdDate.Text = "";
            txt_terms.Text = "";
            txt_deliveryAddress.Text = "";
            txt_vendorID.Text = "";
            txt_total.Text = "";
            txt_orderStatus.Text = "";
        }
    }


    
}
