﻿namespace Stock_Control
{


    partial class AccountsPayableDataSet
    {
    }
}
