﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stock_Control
{
    public partial class ProductOrder : Form
    {
        public ProductOrder()
        {
            InitializeComponent();
            disp_Orders_View();
            DisplayData();

            dgvProducts.RowHeaderMouseClick += new DataGridViewCellMouseEventHandler(DgvProducts_RowHeaderMouseClick);

        }

        
        int ID = 0;
        SqlDataAdapter adapt;
        SqlCommand cmd;
        SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-MTC8R1N\MICHAEL;Initial Catalog=AccountsPayable;Integrated Security=True");

        private void btn_addProduct_Click(object sender, EventArgs e)
        {
            conn.Open();
            cmd = new SqlCommand("INSERT INTO TBL_PO_ITEMS (NUM_POID, NUM_itemID, NUM_quantity)" +
                "VALUES(@NUM_POID, @NUM_itemID, @NUM_quantity)", conn);

            if (txt_orderID.Text == "" || txt_itemID.Text == "" || txt_quantity.Text == "")
            {
                MessageBox.Show("Please fill all fields");
            }

            else
            {
                cmd.Parameters.AddWithValue("@NUM_POID", txt_orderID.Text);
                cmd.Parameters.AddWithValue("@NUM_itemID", txt_itemID.Text);
                cmd.Parameters.AddWithValue("@NUM_quantity", txt_quantity.Text);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Item added Successfully");

                ClearData();
            }
            conn.Close();
        }

        private void ClearData()
        {
            txt_orderID.Text = "";
            txt_itemID.Text = "";
            txt_quantity.Text = "";
            txt_ProductName.Text = "";
        }

        private void btn_deleteProduct_Click(object sender, EventArgs e)
        {
            conn.Open();
            if (txt_orderID.Text == "")
            {
                MessageBox.Show("Enter Order ID to proceed");
            }
            else if (txt_itemID.Text == "")
            {
                MessageBox.Show("Enter Product ID to proceed");
            }

            else
            {
                String query = "DELETE FROM TBL_PO_ITEMS WHERE NUM_POID = '" + txt_orderID.Text + "'";

                SqlDataAdapter SDA = new SqlDataAdapter(query, conn);
                SDA.SelectCommand.ExecuteNonQuery();

                MessageBox.Show("Deleted Successfully");

                ClearData();
            }
            conn.Close();
        }

        private void btn_refresh_Click(object sender, EventArgs e)
        {
            disp_Orders_View();
        }
        public void disp_Orders_View()
        {
            //SqlCommand cmd = new SqlCommand("select * from TBL_PO_ITEMS WHERE NUM_POID = '" + txt_orderID.Text + "'", conn);

            conn.Open();
            DataTable dt1 = new DataTable();
            adapt = new SqlDataAdapter("Select NUM_POID, NUM_itemID, NUM_quantity from TBL_PO_ITEMS", conn);
            adapt.Fill(dt1);
            dgvProductOrder.DataSource = dt1;

            dgvProductOrder.Columns[0].HeaderCell.Value = "Order ID";
            dgvProductOrder.Columns[1].HeaderCell.Value = "Item ID";
            dgvProductOrder.Columns[2].HeaderCell.Value = "Quantity";

            //cmd.ExecuteNonQuery();
            
            
            
            conn.Close();
        }

        private void dgvSuppliers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void DisplayData()
        {
            conn.Open();
            DataTable dt1 = new DataTable();
            adapt = new SqlDataAdapter("Select NUM_itemID,CHR_item_name,FT_price,CHR_info, NUM_manufacturer,NUM_Quantity, CHR_Product_saleflag,TBL_VAT_CATEGORIES.NUM_Vat_rate, NUM_Product_category, NUM_Barcode from TBL_SC_ITEMS FULL JOIN TBL_VAT_CATEGORIES ON TBL_SC_ITEMS.NUM_Vat_category=TBL_VAT_CATEGORIES.NUM_Vat_id", conn);
            adapt.Fill(dt1);
            dgvProducts.DataSource = dt1;

            this.dgvProducts.DefaultCellStyle.ForeColor = Color.Blue;

            dgvProducts.Columns[0].HeaderCell.Value = "ID";
            dgvProducts.Columns[1].HeaderCell.Value = "Name";
            dgvProducts.Columns[2].HeaderCell.Value = "Price";
            dgvProducts.Columns[3].HeaderCell.Value = "Info";
            dgvProducts.Columns[4].HeaderCell.Value = "Vendor";
            dgvProducts.Columns[5].HeaderCell.Value = "Quantity";
            dgvProducts.Columns[6].HeaderCell.Value = "Sale Flag";
            dgvProducts.Columns[7].HeaderCell.Value = "VAT";
            dgvProducts.Columns[8].HeaderCell.Value = "Category";
            dgvProducts.Columns[9].HeaderCell.Value = "Barcode";

            conn.Close();
        }

        private void DgvProducts_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            ID = Convert.ToInt32(dgvProducts.Rows[e.RowIndex].Cells[0].Value.ToString());
            txt_itemID.Text = dgvProducts.Rows[e.RowIndex].Cells[0].Value.ToString();
         
        }

        private void dgvProducts_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btn_Search_Click(object sender, EventArgs e)
        {
            if (txt_orderID.Text == "")
            {
                MessageBox.Show("Please Enter A Value In Product ID");
                disp_Orders_View();
            }
            else
            {
                conn.Open();
                SqlCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "SELECT * FROM TBL_PO_ITEMS where NUM_POID = '" + txt_orderID.Text + "'";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                dgvProductOrder.DataSource = dt;
                conn.Close();
                ClearData();
            }
        }

        private void btn_SearchProduct_Click(object sender, EventArgs e)
        {
            if(txt_ProductName.Text == "")
            {
                MessageBox.Show("Please Enter A Product Name");
                DisplayData();
            }
            else
            {
                SqlCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "SELECT * FROM TBL_SC_ITEMS where CHR_item_name = '" + txt_ProductName.Text + "'";

                conn.Open();

                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                dgvProducts.DataSource = dt;

                
                
                conn.Close();
                ClearData();
            }
            
        }
    }
}
